import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;
import java.util.stream.Collectors;

public class TreeMapSortByValue {
	public static void main(String[] args) {
		Map<String, String> unsortedFruits = new TreeMap<>();
		Map<String, String> sortedFruits;
		unsortedFruits.put("one", "Papaya");
		unsortedFruits.put("two", "Guava");
		unsortedFruits.put("three", "Water Melon");
		unsortedFruits.put("four", "Mango");
		unsortedFruits.put("five", "Grapes");
		unsortedFruits.put("six", "Apple");
		System.out.println("Before Sorting......");
		printData(unsortedFruits);

		// sorting using java8
		sortedFruits = sortUsingJava8(unsortedFruits);
		System.out.println("After Sorting......");
		printData(sortedFruits);

		// sorting before java8
		sortedFruits = sortBeforeJava8(unsortedFruits);
		printData(sortedFruits);
	}

	private static Map<String, String> sortBeforeJava8(Map<String, String> unsortedFruits) {
		LinkedList<Entry<String, String>> list = new LinkedList<>(unsortedFruits.entrySet());
		Collections.sort(list, new Comparator<Map.Entry<String, String>>() {
			@Override
			public int compare(Entry<String, String> o1, Entry<String, String> o2) {
				return o1.getValue().compareTo(o2.getValue());
			}
		});

		LinkedHashMap<String, String> sortedMap = new LinkedHashMap<>();
		for (Entry<String, String> entry : list) {
			sortedMap.put(entry.getKey(), entry.getValue());
		}
		return sortedMap;
	}

	private static LinkedHashMap<String, String> sortUsingJava8(Map<String, String> unsortedFruits) {
		return unsortedFruits.entrySet().stream().sorted(Entry.comparingByValue()) // to
																					// sort
																					// values
				.collect(Collectors.toMap(Entry::getKey, Entry::getValue, (e1, e2) -> e1, LinkedHashMap::new));
	}

	private static void printData(Map<String, String> map) {
		System.out.println(map);
		// map.entrySet().stream().forEach(e -> System.out.println(e.getKey() +
		// "::" + e.getValue()));
	}

}
