prerequisites of java stream api
1. Introduction to Stream API.
2. Prerequisite -
	a. Lambda expressions.
	b. Constructor and Method references.
	c. Built-In functional interfaces. - 
		1. Supplier
		2. Consumer and BiConsumer
		3. Function and BiFunction
		4. Predicate and BiPredicate
		5. UnaryOperator and BinaryOperator